import { Component } from '@angular/core';

@Component({
  selector: 'app-artista',
  standalone: true,
  imports: [],
  templateUrl: './artista.component.html',
  styleUrl: './artista.component.css',
})
export class ArtistaComponent {}
